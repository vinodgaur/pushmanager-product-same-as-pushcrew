/*=======GOOGLE CHROME======*/
if ('serviceWorker' in navigator) { 
  navigator.serviceWorker.register('push_notification/sw.js').then(function(registration) {
  // Registration was successful 
  console.log('ServiceWorker registration successful with scope: ',    registration.scope);
  registration.pushManager.subscribe({userVisibleOnly: true}).then(function(subscription){
  isPushEnabled = true;  
  console.log("subscription.subscriptionId: ", subscription.subscriptionId);
  console.log("subscription.endpoint: ", subscription.endpoint);
  window.localStorage.setItem('endpoint',subscription.endpoint);
  collectSubsciptionAjaxCall(subscription);
  
  // TODO: Send the subscription subscription.endpoint
  // to your server and save it to send a push message
  // at a later date
  return ;//sendSubscriptionToServer(subscription);
  });
  }).catch(function(err) {
    // registration failed :(
    console.log('ServiceWorker registration failed: ', err);
  });
}
/*=======END GOOGLE CHROME======*/



/*=======MOZILLA FIREFOX======*/
/*if (self.navigator.push) {
  // Request the endpoint. This uses PushManager.register().
  var req = navigator.push.register();
  
  req.onsuccess = function(e) {
    var endpoint = req.result;
      console.log("New endpoint: " + endpoint );
      // At this point, you'd use some call to send the endpoint to your server. 
      // For instance:
       
      var post = XMLHTTPRequest();
      post.open("POST", "https://your.server.here/registerEndpoint");
      post.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
      post.send("endpoint=" + encodeURIComponents( endpoint ) );
      
      // Obviously, you'll want to add .onload and .onerror handlers, add user id info,
      // and whatever else you might need to associate the endpoint with the user.
    }

   req.onerror = function(e) {
     console.error("Error getting a new endpoint: " + JSON.stringify(e));
   }
} else {
  // push is not available on the DOM, so do something else.
}*/

// re-register
/*if (self.navigator.mozSetMessageHandler) {
  self.navigator.mozSetMessageHandler('push-register', function(e) {
    console.log('push-register received, I need to register my endpoint(s) again!');

    var req = navigator.push.register();
    req.onsuccess = function(e) {
      var endpoint = req.result;
      console.log("New endpoint: " + endpoint );
      localStorage.endpoint = endpoint;
    }

    req.onerror = function(e) {
      console.error("Error getting a new endpoint: " + JSON.stringify(e));
    }
  });
} else {
  
}*/


/*=======END MOZILLA FIREFOX======*/

function collectSubsciptionAjaxCall(sub) {
  var endpoint = (sub.endpoint).split('send/')[1];
  var data = JSON.stringify({"username":"", "usernameType":"", "subscription":endpoint})

  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      console.log('collectSubsciptionAjaxCall response = ', this.responseText);
    }
  };
  xhttp.open("POST", "/apipushmanager/notificationsubscription", true);
  xhttp.setRequestHeader("Content-Type", "application/json");
  xhttp.setRequestHeader("X-CSRF-TOKEN", "HqVN5oIXrc7I4zfnh26g7oxLHJAKs8wDGSiZ3gec");
  xhttp.send(data);
}