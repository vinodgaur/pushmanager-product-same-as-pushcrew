@extends('common::layouts.blank')

@push('stylesheets')
    
@endpush

@section('main_container')
    
    <!-- page content -->
    <div class="right_col" role="main">
    <a href="">Download Kit</a>
    </div>
    <!-- /page content -->
    
@endsection

@push('scripts')

@endpush