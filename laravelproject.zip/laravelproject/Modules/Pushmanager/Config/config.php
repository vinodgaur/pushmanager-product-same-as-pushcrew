<?php

return [
	'name' => 'Pushmanager'
];