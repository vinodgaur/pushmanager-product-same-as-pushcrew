<?php

Route::group(['middleware' => 'web', 'prefix' => 'pushmanager', 'namespace' => 'Modules\Pushmanager\Http\Controllers'], function()
{
	Route::get('/', 'PushmanagerController@index');
	Route::get('/analytics', 'PushmanagerController@analytics');
	Route::get('/integrate', 'PushmanagerController@integrate');
});