<?php

namespace Modules\Apipushmanager\Entities;

use Illuminate\Database\Eloquent\Model;

class Notificationsubscription extends Model
{
	// Define table name explicitly
    protected $table = 'notificationsubscription';
    protected $primaryKey = 'id';

    protected $fillable = ["usernameType", "username", "subscription"]; // only allowed field can be update 
    protected $guarded = array('id'); // to protect from update

    //Define validation rules here
    public static $rules = array(
      'subscription' => 'required'
    );
}
