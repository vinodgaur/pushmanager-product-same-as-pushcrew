<?php

namespace Modules\Apipushmanager\Jobs;

use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Bus\Queueable;

class SendPush implements ShouldQueue
{
    use InteractsWithQueue, SerializesModels, Queueable;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        //
        // API access key from Google API's Console
        define( 'API_ACCESS_KEY', 'key=AIzaSyAzOS6IytjmPrGnAxX0CO1rUiIZaVhEi9Q' );
        
        $ch = curl_init();
        for($i = 0; $i < 1; $i++){
        $registrationIds = array( 'fHRNd-AM6BI:APA91bGnNZ72mt8fXUKcsk0X6uTfPzNTWxiJYJ6ibLBc0Iaua8LNhQHjMUGiOLIuOUya1W9sniSEFyCOZxm1g3mTvjDLamULC9JhsWU6-39U6kcwvu5ewbXc2ktJEidDvRdcBUPccYtP' );
        //$registrationIds = $request->only('subscription');

        // prep the bundle
        $msg = array
        (
            'message'   => 'here is a message. message',
            'title'     => 'This is a title. title',
            'subtitle'  => 'This is a subtitle. subtitle',
            'tickerText'    => 'Ticker text here...Ticker text here...Ticker text here',
            'vibrate'   => 1,
            'sound'     => 1,
            'largeIcon' => 'large_icon',
            'smallIcon' => 'small_icon'
        );
        $fields = array
        (
            'registration_ids'  => $registrationIds,
            'data'          => $msg
        );
         
        $headers = array
        (
            'Authorization: '.API_ACCESS_KEY,
            'Content-Type: application/json'
        );
         
        //$curl = new anlutro\cURL\cURL;

        
        curl_setopt( $ch,CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
        curl_setopt( $ch,CURLOPT_POST, true );
        curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
        curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
        curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
        $result = curl_exec($ch );
        }
        curl_close( $ch );
    }
}
