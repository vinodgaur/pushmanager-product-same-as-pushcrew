<?php

Route::group(['middleware' => 'web', 'prefix' => 'apipushmanager', 'namespace' => 'Modules\Apipushmanager\Http\Controllers'], function()
{
	Route::get('/', 'ApipushmanagerController@index');
	Route::get('/sendpushnotification', 'ApipushmanagerController@sendpushnotification');
	
	Route::resource('notificationsubscription', 'ApipushmanagerController');
});