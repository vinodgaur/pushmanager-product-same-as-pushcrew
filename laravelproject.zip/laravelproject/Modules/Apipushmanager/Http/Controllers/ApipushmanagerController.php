<?php

namespace Modules\Apipushmanager\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Apipushmanager\Entities\Notificationsubscription;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Log;
use Modules\Apipushmanager\Jobs\SendPush;
//use Modules\Apipushmanager\Http\Controllers\Debugbar;

class ApipushmanagerController extends Controller
{
	/**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        $users = Notificationsubscription::all();
        return $users;
    }

    public function sendpushnotification()
    {
        dispatch((new SendPush())->delay(10)); // delay is in seconds

        return 'Testing job';



        // API access key from Google API's Console
        define( 'API_ACCESS_KEY', 'key=AIzaSyAzOS6IytjmPrGnAxX0CO1rUiIZaVhEi9Q' );

        $registrationIds = array( 'fHRNd-AM6BI:APA91bGnNZ72mt8fXUKcsk0X6uTfPzNTWxiJYJ6ibLBc0Iaua8LNhQHjMUGiOLIuOUya1W9sniSEFyCOZxm1g3mTvjDLamULC9JhsWU6-39U6kcwvu5ewbXc2ktJEidDvRdcBUPccYtP' );
        //$registrationIds = $request->only('subscription');

        // prep the bundle
        $msg = array
        (
            'message'   => 'here is a message. message',
            'title'     => 'This is a title. title',
            'subtitle'  => 'This is a subtitle. subtitle',
            'tickerText'    => 'Ticker text here...Ticker text here...Ticker text here',
            'vibrate'   => 1,
            'sound'     => 1,
            'largeIcon' => 'large_icon',
            'smallIcon' => 'small_icon'
        );
        $fields = array
        (
            'registration_ids'  => $registrationIds,
            'data'          => $msg
        );
         
        $headers = array
        (
            'Authorization: '.API_ACCESS_KEY,
            'Content-Type: application/json'
        );
         
        //$curl = new anlutro\cURL\cURL;

        $ch = curl_init();
        curl_setopt( $ch,CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
        curl_setopt( $ch,CURLOPT_POST, true );
        curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
        curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
        curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
        $result = curl_exec($ch );
        curl_close( $ch );
        return response()->json(['success' => true]);
    }


    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
        return "notificationsubscription create";
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        $requestParamArr = $request->only('usernameType', 'username', 'subscription');

        $validation = Validator::make($requestParamArr, Notificationsubscription::$rules);  
        if ($validation->passes())
        {
            $newRecord = Notificationsubscription::create($requestParamArr);
            if($newRecord->save()){
                return response()->json(['success' => true]);
            } else {
                return response()->json(['success' => false]);
            }
        }
        return response()->json(['success' => false, 'message' => $validation->failed()]);
    }
    
    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit()
    {
        return view('apipushmanager::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request)
    {
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy()
    {
    }
}
