<?php

Route::group(['middleware' => 'web', 'prefix' => '', 'namespace' => 'Modules\Client\Http\Controllers'], function()
{
	Route::get('/', 'ClientController@index');
	Route::get('/dashboard', 'ClientController@dashboard');
});