<?php $__env->startPush('stylesheets'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main_container'); ?>
    
    csrf = <input type="text" name="_token" value="<?php echo csrf_token(); ?>">
    
    <!-- page content -->
    <div class="right_col" role="main">
      <!-- top tiles -->
      <div class="row tile_count">
        <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
          <span class="count_top"><i class="fa fa-user"></i> Total Users</span>
          <div class="count">2500</div>
          <span class="count_bottom"><i class="green">4% </i> From last Week</span>
        </div>
        <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
          <span class="count_top"><i class="fa fa-clock-o"></i> Average Time</span>
          <div class="count">123.50</div>
          <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>3% </i> From last Week</span>
        </div>
        <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
          <span class="count_top"><i class="fa fa-user"></i> Total Males</span>
          <div class="count green">2,500</div>
          <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>34% </i> From last Week</span>
        </div>
        <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
          <span class="count_top"><i class="fa fa-user"></i> Total Females</span>
          <div class="count">4,567</div>
          <span class="count_bottom"><i class="red"><i class="fa fa-sort-desc"></i>12% </i> From last Week</span>
        </div>
        <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
          <span class="count_top"><i class="fa fa-user"></i> Total Collections</span>
          <div class="count">2,315</div>
          <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>34% </i> From last Week</span>
        </div>
        <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
          <span class="count_top"><i class="fa fa-user"></i> Total Connections</span>
          <div class="count">7,325</div>
          <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>34% </i> From last Week</span>
        </div>
      </div>
      <!-- /top tiles -->

      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="dashboard_graph">
                <button type="button" onclick="sendPushNotification()">Send Notification</button>

                <div class="clearfix"></div>
          </div>
        </div>
      </div>
      <br />

    </div>
    <!-- /page content -->
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function sendPushNotification(){
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log('sendpushnotification response = ', this.responseText);
        }
    };
    xhttp.open("GET", "/apipushmanager/sendpushnotification", true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    xhttp.setRequestHeader("X-CSRF-TOKEN", "HqVN5oIXrc7I4zfnh26g7oxLHJAKs8wDGSiZ3gec");
    xhttp.send();
}
</script
<?php $__env->stopPush(); ?>
<?php echo $__env->make('common::layouts.blank', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>