<?php $__env->startPush('stylesheets'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main_container'); ?>
    
    <!-- page content -->
    <div class="right_col" role="main">
    <a href="">Download Kit</a>
    </div>
    <!-- /page content -->
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('common::layouts.blank', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>